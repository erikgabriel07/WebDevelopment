<?php
$server = mysqli_connect('localhost', 'root', '', 'produtos');